import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part
{
	public static void main(String args[])throws Exception
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		Transaction tx=ss.beginTransaction();
		 Query qry = ss.createQuery("insert into mypojo(rollno, name, address) " +
	             "select :rollno, :name, :address from mypojo");
         qry.setParameter("rollno","ECE-190");
         qry.setParameter("name","sandip");
         qry.setParameter("address","Hydrabad");
          int res = qry.executeUpdate();
         tx.commit();
         System.out.println("Command successfully executed....");
         System.out.println("Numer of records effected due to insert query"+res);
	}
}



/*
 * create table details1(rollno varchar(30),name varchar(30),address  varchar(30));
 * 
 * insert into details1 values('ECE-190','sandip','Bangalore');
 * 
 *
 */