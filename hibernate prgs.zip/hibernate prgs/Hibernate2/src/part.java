import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part
{
	public static void main(String args[])throws Exception
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		Transaction tx=ss.beginTransaction();
		 Query qry = ss.createQuery("delete from mypojo p where p.rollno=?");
         qry.setParameter(0,"ECE-190");
         int res = qry.executeUpdate();
         tx.commit();
         System.out.println("Command successfully executed....");
         System.out.println("Numer of records effected due to delete query"+res);
	}
}



/*
 * create table details1(rollno varchar(30),name varchar(30),address  varchar(30));
 * 
 * insert into details1 values('ECE-190','sandip','Bangalore');
 * 
 *
 */