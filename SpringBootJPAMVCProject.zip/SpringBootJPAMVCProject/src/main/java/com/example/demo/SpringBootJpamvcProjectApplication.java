package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpamvcProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpamvcProjectApplication.class, args);
	}

}
