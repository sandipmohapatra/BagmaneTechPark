<%@ page import="mybeans.LanguageBean" %>

<jsp:useBean id="obj" class="mybeans.LanguageBean" scope="page" />

<jsp:setProperty name="obj" property="*" />

<html><head>
<title>useBean action test result</title>
</head><body>
<h1>useBean action test result</h1>
<p>Hello, <jsp:getProperty name="obj" property="name" />.</p>
<p>Your Language is 
<jsp:getProperty name="obj" property="language" />.</p>
<p> My comments on your language: </p>
<p><jsp:getProperty name="obj" property="languageComments" />
</p></body>   </html>