import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part
{
	public static void main(String args[])throws Exception
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		Transaction tx=ss.beginTransaction();
		Query q=ss.createQuery("from mypojo");
		List stud=q.list();
		Iterator it=stud.iterator();
		while(it.hasNext())
		{
			pojo=(mypojo)it.next();
			System.out.println(pojo.getRollno());
			System.out.println(pojo.getName());
			System.out.println(pojo.getAddress());
		}
		
	}
}



/*
 * create table details1(rollno varchar(30),name varchar(30),address  varchar(30));
 * 
 * insert into details1 values('ECE-190','sandip','Bangalore');
 * 
 *
 */