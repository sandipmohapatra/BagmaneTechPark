package com.example.SpringBootExample2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
@SpringBootApplication
public class SpringBootExample2Application {

	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(SpringBootExample2Application.class, args);
		MyMessage mm=ac.getBean("msg",MyMessage.class);
		mm.welcome();
		System.out.println(mm.sum(10,20));
		
		TestDemo ts=ac.getBean("test",TestDemo.class);
		System.out.println(ts.sub(30, 20));
		System.out.println(ts.mul(20, 20));

	
	}

}
