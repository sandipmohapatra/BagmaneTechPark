package com.example.SpringBootExample2;

import org.springframework.stereotype.Component;
@Component("test")
public class TestDemo 
{
		
	public int sub(int a,int b)
	{
		return a-b;
	}
	public int mul(int a,int b)
	{
		return a*b;
	}
}
