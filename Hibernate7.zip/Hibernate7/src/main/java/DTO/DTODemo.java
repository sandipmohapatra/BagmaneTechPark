package DTO;
import javax.persistence.*;
@Entity
@Table(name="TestTable")
public class DTODemo
{
@Id
@Column(name="id")
int id;
@Column(name="name")
String name;
@Column(name="address")
String address;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "DTODemo [id=" + id + ", name=" + name + ", address=" + address + "]";
}


}
