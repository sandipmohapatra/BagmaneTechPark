package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringBootCore1Application {

	public static void main(String[] args) 
	{
		ApplicationContext ac=SpringApplication.run(SpringBootCore1Application.class, args);
		MyMessage mm=ac.getBean("msg",MyMessage.class);
		mm.welcome();
		System.out.println(mm.sum(5,7));
	}
}
